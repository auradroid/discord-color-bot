# 🎨 Color Hunt Discord Bot

A small Discord bot for a daily real-life Color Hunt.

## Commands

- `/color` — picks a random color from the list
- `/today` — shows today's selected color
- `/colors` — shows the complete color list
- `/setcolorchannel` — makes the current channel the automatic daily Color Hunt channel

## Automatic daily color

After you run `/setcolorchannel`, the bot posts a new color automatically every day at:

**00:00 Europe/Berlin**

The bot stores the selected color and channel in `state.json`, so it can remember them after a restart.

## Important

The bot must be running continuously for the automatic daily post to happen. If it is offline at midnight, it cannot post at that moment.

## Installation

1. Install Python 3.10+.
2. Install the Discord library:

```bash
pip install -U discord.py
```

3. Create a Discord application/bot in the Discord Developer Portal.
4. Copy the bot token.
5. Set it as an environment variable called `DISCORD_TOKEN`.

### Windows PowerShell

```powershell
$env:DISCORD_TOKEN="YOUR_BOT_TOKEN"
python bot.py
```

### Linux/macOS

```bash
export DISCORD_TOKEN="YOUR_BOT_TOKEN"
python3 bot.py
```

6. Invite the bot to your server with the `bot` and `applications.commands` scopes.
7. Give it permission to:
   - View Channel
   - Send Messages
   - Use Application Commands
8. In the channel where you want the daily color, run:

`/setcolorchannel`

Only members with **Manage Server** can use that setup command.

## Change the colors

Open `bot.py` and edit the `COLORS` list near the top.

Example:

```python
("Emerald Green", "💚"),
("Lavender", "💜"),
("Burgundy", "🍷"),
```

The bot avoids choosing the same color two days in a row when possible.
